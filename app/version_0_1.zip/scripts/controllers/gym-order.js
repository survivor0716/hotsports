'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:GymorderCtrl
 * @description
 * # GymorderCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('GymorderCtrl', function ($log, $scope, GymService) {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];

    GymService.getGymOrder()
      .then(function (data) {
        $log.log(data);
        $scope.order_data = data;
      }, function (errMsg) {
        $scope.errMsg = errMsg;
        $window.alert(errMsg);
      });
  });
