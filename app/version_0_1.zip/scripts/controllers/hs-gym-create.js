'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:HsgymcreateCtrl
 * @description
 * # HsgymcreateCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('HsgymcreateCtrl', function ($log, $window, $scope, $http, $q, ServiceConfig) {
    this.typeList = [];

    this.selectedType = {};

    this.setType = function (type) {
      this.selectedType = type;
    };

    var self = this;

    var promiseSuccessCallback = function (response) {
      $log.debug('Request success', response);
      if (typeof response.data === 'object') {
        var data = response.data;
        if (data.result) {
          return $q.resolve(data.data);
        } else {
          return $q.reject(data.errMsg);
        }
      } else {
        return $q.reject(response.data);
      }
    };

    var promiseFailureCallback = function (response) {
      $log.debug('Request fail', response);
      return $q.reject(response.data);
    };

    (function () {
      $http.post(ServiceConfig.sport_type, {}, {'withCredentials': true})
        .then(promiseSuccessCallback, promiseFailureCallback)
        .then(function (data) {
          $log.log('获取场馆类型列表成功', data);
          self.typeList = data;
        }, function (errMsg) {
          $log.log('获取场馆类型列表失败', errMsg);
          $window.alert(errMsg);
        });
    }());

    this.submit = function () {
      var params = {
        name: this.name,
        tel: this.tel,
        lat: this.lat,
        lng: this.lng,
        sportType: [this.selectedType.id]
      };
      $log.debug('创建场馆请求参数', params);
      $http.post(ServiceConfig.hs_gym_add, params, {'withCredentials': true})
        .then(promiseSuccessCallback, promiseFailureCallback)
        .then(function (data) {
          $log.log('添加场馆成功', data);
          $window.alert('添加场馆成功');
        }, function (errMsg) {
          $log.log('添加场馆失败', errMsg);
          $window.alert(errMsg);
        });
    };

  });
