'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:HsgymdetailCtrl
 * @description
 * # HsgymdetailCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
    .controller('HsgymdetailCtrl', function ($log, $window, $scope, $http, $q, $routeParams, ServiceConfig, PromiseCallback, detailData) {
        $log.log('场馆详情:', detailData);
        this.gymData = detailData.gym;
        this.gymType = detailData.type;
        this.superManagerData = detailData.superManager;
        this.cashierData = detailData.cashier;
        this.accountData = detailData.account;

        this.submit = function () {
            var params = {
                nickName: this.nickName,
                phone: this.phone,
                gid: this.gymData.id,
                receiveMsg: 1
            };
            $log.debug('创建场馆管理员请求参数', params);
            $http.post(ServiceConfig.hs_sm_add, params, {'withCredentials': true})
                .then(PromiseCallback.successCallback, PromiseCallback.failureCallback)
                .then(function (data) {
                    $log.log('添加场馆成功', data);
                    $window.alert('添加场馆成功');
                }, function (errMsg) {
                    $log.log('添加场馆失败', errMsg);
                    $window.alert(errMsg);
                });
        };

        this.submitAddAccountInfo = function () {
            var params = {
                accNum: this.accNum,
                accName: this.accName,
                accBank: this.accBank,
                bankCode: this.bankCode,
                type: 'PERSONAL',
                phone: this.accPhone,
                gid: this.gymData.id,
                default: true
            };
            $http.post(ServiceConfig.hs_gym_account_add, params, {'withCredentials': true})
                .then(PromiseCallback.successCallback, PromiseCallback.failureCallback)
                .then(function (data) {
                    $log.log('添加提现账户成功', data);
                    $window.alert('添加提现账户成功');
                }, function (errMsg) {
                    $log.log('添加提现账户失败', errMsg);
                    $window.alert(errMsg);
                });
        }
    });
