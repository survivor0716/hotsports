'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:CoachLoginCtrl
 * @description
 * # CoachLoginCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('CoachLoginCtrl', function ($log, $window, $scope, CoachService, $location, ServiceConfig) {
    //$scope.coachPhone = '18600037389';
    //$scope.coachPassword = '123456';
    //$scope.errMsg = '';
    //
    //$scope.encryptCredentials = function () {
    //  $scope.coachPassword = $.md5('hotsports' + $scope.coachPassword + $scope.coachPassword.substr(0, 1)).substr(8, 16);
    //  //return $scope.credentials;
    //};
    //
    //$scope.login = function () {
    //  $scope.encryptCredentials();
    //  if(!isMobile($scope.coachPhone)) {
    //    $scope.errMsg = '请输入正确的手机号码';
    //  } else {
    //    CoachService.login({phone: $scope.coachPhone, password: $scope.coachPassword})
    //      .then(function (data) {
    //        $log.debug(data);
    //        CoachService.setQrcode(ServiceConfig.coach_qrcode + '?sign=' + data.sign + '&uid=' + data.uid);
    //        //$location.url('/coach/qrcode');
    //        $window.location.href = 'http://app.hotsports.cn/qrcode/index.html?qrcode=' + encodeURIComponent(CoachService.qrcode_url);
    //      }, function (errMsg) {
    //        $scope.errMsg = errMsg;
    //      });
    //  }
    //};
    //
    //function isMobile(str) {
    //  var reg = /^0?1[3|4|5|8|6|7][0-9]\d{8}$/;
    //  return reg.test(str);
    //}
  });
