'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
