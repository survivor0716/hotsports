'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:ContactCtrl
 * @description
 * # ContactCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('ContactCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
