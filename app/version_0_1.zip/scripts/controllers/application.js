'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:ApplicationCtrl
 * @description
 * # ApplicationCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
    .controller('ApplicationCtrl', function ($window, $scope, $location, $route, USER_ROLES, AuthService) {
        $scope.currentUser = null;
        $scope.userRoles = USER_ROLES;
        $scope.isAuthenticated = AuthService.isAuthenticated;
        $scope.isAuthorized = AuthService.isAuthorized;
        $scope.logout = function () {
            AuthService.logout()
                .then(function () {
                    $("#js-navbar-collapse").collapse('toggle');
                    $scope.currentUser = null;
                    $location.url('login');
                }, function () {
                    $window.alert('网络异常');
                });
        };

        if ($window.sessionStorage.userInfo) {
            $scope.currentUser = JSON.parse($window.sessionStorage.userInfo);
        }

        $scope.setCurrentUser = function (user) {
            $scope.currentUser = user;
        };

        $scope.panelStyle = 'panel-primary';

        $scope.changeStyle = function (style) {
            $scope.panelStyle = style;
        }
    });
