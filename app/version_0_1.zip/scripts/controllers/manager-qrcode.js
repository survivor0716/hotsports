'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:ManagerQrcodeCtrl
 * @description
 * # ManagerQrcodeCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('ManagerQrcodeCtrl', function ($log, $scope, ServiceConfig, Session) {
    //$scope.qrcode_src = ServiceConfig.manager_qrcode + '?uid=' + Session.userId;
    $scope.qrcode_src = '';
  });
