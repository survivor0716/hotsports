'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:SmgymoverviewCtrl
 * @description
 * # SmgymoverviewCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
    .config(['$routeProvider', 'USER_ROLES', 'RouteAuthResolveProvider', function ($routeProvider, USER_ROLES, RouteAuthResolveProvider) {
        //Note that Angular appends 'Provider' to then end of the provider name
        $routeProvider
            .when('/sm/gym-overview/:gymid?', {
                templateUrl: 'views/sm-gym-overview.html',
                controller: 'SmgymoverviewCtrl',
                controllerAs: 'smGymOverview',
                resolve: {
                    'auth': RouteAuthResolveProvider.auth([USER_ROLES.superManager, USER_ROLES.manager]),
                    'gymOverviewData': ['$q', '$route', 'SuperManagerService', function ($q, $route, SuperManagerService) {
                        var params = {gid: $route.current.params.gymid};
                        return SuperManagerService.gymOverview(params)
                            .then(function (data) {
                                return $q.resolve(data);
                            }, function (errMsg) {
                                //TODO: $routeChangeError event
                                return $q.reject(errMsg);
                            });

                    }],
                    'gymOrderData': ['$q', '$route', 'SuperManagerService', function ($q, $route, SuperManagerService) {
                        var params = {gid: $route.current.params.gymid, row: 10};
                        return SuperManagerService.gymOrder(params)
                            .then(function (data) {
                                return $q.resolve(data);
                            }, function (errMsg) {
                                //TODO: $routeChangeError event
                                return $q.reject(errMsg);
                            });

                    }]
                }
            })
    }])
    .controller('SmgymoverviewCtrl', function ($log, $window, $scope, $location, $route, Session, Alerts, gymOverviewData, gymOrderData, SuperManagerService) {
        $log.log('Injected Oerview Data: ', gymOverviewData);
        this.gymData = gymOverviewData.gym;
        this.superManagerData = gymOverviewData.superManager || [];
        this.cashierData = gymOverviewData.cashier || [];
        $log.log('Injected Order Data: ', gymOrderData);
        this.orderData = gymOrderData;
        //将场馆id存入Session服务中
        Session.gid = this.gymData.id;

        this.showAddCashierForm = false;

        var self = this;

        //添加（绑定）收银员
        this.submitAddCashier = function () {
            var params = {
                gid: this.gymData.id,
                nickName: this.nickName,
                phone: this.phone,
                code: this.code
            };
            $log.log('添加场馆收银员请求参数', params);
            SuperManagerService.gymAddCashier(params)
                .then(function (data) {
                    $log.log('添加场馆收银员成功', data);
                    //$window.alert('创建场馆收银员成功');
                    Alerts.showAlert($scope, 'alert-success', '添加场馆收银员成功', true, true, 3);
                    //TODO: 后台回调给出完整cashier list
                    self.cashierData.push({id: data.uid, nickName: params.nickName, phone: params.phone});
                }, function (errMsg) {
                    $log.log('添加场馆收银员失败', errMsg);
                    //$window.alert(errMsg);
                    Alerts.showAlert($scope, 'alert-danger', errMsg, true, true, 3);
                });

        };

        //移除（解绑）收银员
        this.submitRemoveCashier = function (id) {
            var params = {uid: id};
            $log.debug('移除场馆收银员请求参数', params);
            SuperManagerService.gymRemoveCashier(params)
                .then(function (data) {
                    $log.log('移除场馆收银员成功', data);
                    //$window.alert('创建场馆收银员成功');
                    Alerts.showAlert($scope, 'alert-success', '移除场馆收银员成功', true, true, 3);
                    self.cashierData = data;
                }, function (errMsg) {
                    $log.log('移除场馆收银员失败', errMsg);
                    //$window.alert(errMsg);
                    Alerts.showAlert($scope, 'alert-danger', errMsg, true, true, 3);
                });

        };

        //发送短信验证码
        this.smsCode = function () {
            SuperManagerService.smsCode(this.phone)
                .then(function (data) {
                    $window.alert('已发送短信验证码');
                }, function (errMsg) {
                    $window.alert(errMsg);
                });
        };

        //提现
        this.withdraw = function () {
            var params = {
                fee: 500,
                aid: this.gymData.aid,
                gid: this.gymData.id

            };
            SuperManagerService.gymWithdraw(params)
                .then(function (data) {
                    $log.log('申请提现成功', data);
                    $window.alert(data);
                }, function (errMsg) {
                    $log.log('申请提现失败', errMsg);
                    $window.alert(errMsg);
                });
        };

        this.toggleAddCashierForm = function () {
            this.showAddCashierForm = !this.showAddCashierForm;
        }
    });
