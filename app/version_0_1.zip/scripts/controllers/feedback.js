'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:FeedbackCtrl
 * @description
 * # FeedbackCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('FeedbackCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
