'use strict';

/**
 * @ngdoc function
 * @name hotsportsApp.controller:CoachInfoCtrl
 * @description
 * # CoachInfoCtrl
 * Controller of the hotsportsApp
 */
angular.module('hotsportsApp')
  .controller('CoachInfoCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
